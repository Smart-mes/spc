const url = 'http://120.78.70.56:8099'

export default {
  baseURL: process.env.NODE_ENV === 'development' ? '' : url,
}
